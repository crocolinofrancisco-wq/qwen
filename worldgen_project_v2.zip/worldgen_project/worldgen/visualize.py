"""Colored visualizations of the world (matplotlib-compatible RGB arrays)."""
import numpy as np


def _lerp(a, b, t):
    return a + (b - a) * t


def color_height(h):
    H, W = h.shape
    rgb = np.zeros((H, W, 3), dtype=np.float32)
    ocean = h < 0
    d = np.clip(-h[ocean], 0, 1)
    rgb[ocean, 0] = _lerp(0.05, 0.02, d)
    rgb[ocean, 1] = _lerp(0.25, 0.05, d)
    rgb[ocean, 2] = _lerp(0.6, 0.25, d)
    land = ~ocean
    lh = np.clip(h[land], 0, 1)
    rgb[land, 0] = np.where(lh < 0.6, _lerp(0.2, 0.55, lh / 0.6), _lerp(0.55, 1.0, (lh - 0.6) / 0.4))
    rgb[land, 1] = np.where(lh < 0.6, _lerp(0.55, 0.4, lh / 0.6), _lerp(0.4, 1.0, (lh - 0.6) / 0.4))
    rgb[land, 2] = np.where(lh < 0.6, _lerp(0.2, 0.25, lh / 0.6), _lerp(0.25, 1.0, (lh - 0.6) / 0.4))
    return np.clip(rgb, 0, 1)


def color_temperature(t):
    H, W = t.shape
    rgb = np.zeros((H, W, 3), dtype=np.float32)
    tt = np.clip(t, 0, 1)
    rgb[..., 0] = tt
    rgb[..., 2] = 1 - tt
    rgb[..., 1] = 0.4 * (1 - np.abs(tt - 0.5) * 2)
    return rgb


def color_precip(p):
    H, W = p.shape
    rgb = np.zeros((H, W, 3), dtype=np.float32)
    pp = np.clip(p, 0, 1)
    rgb[..., 2] = pp
    rgb[..., 1] = pp * 0.7
    rgb[..., 0] = (1 - pp) * 0.8
    return rgb


def color_plates(plate_map, plates):
    n = max(1, len(plates))
    rng = np.random.default_rng(42)
    palette = rng.random((n, 3)).astype(np.float32)
    for i, p in enumerate(plates):
        if p.is_oceanic:
            palette[i] *= 0.4
            palette[i, 2] = min(1.0, palette[i, 2] + 0.3)
    # protect against out-of-range plate ids (from drift)
    max_id = int(plate_map.max())
    if max_id >= n:
        extra = np.random.default_rng(43).random((max_id - n + 1, 3)).astype(np.float32)
        palette = np.concatenate([palette, extra], axis=0)
    return palette[plate_map]


def color_boundaries(boundary_type):
    H, W = boundary_type.shape
    rgb = np.zeros((H, W, 3), dtype=np.float32)
    rgb[boundary_type == 1] = [0.2, 0.6, 1.0]
    rgb[boundary_type == 2] = [1.0, 0.2, 0.2]
    rgb[boundary_type == 3] = [1.0, 0.9, 0.2]
    return rgb


def color_final(height, temp, precip, river_map):
    rgb = color_height(height)
    dry = (precip < 0.2) & (height >= 0)
    rgb[dry] = rgb[dry] * 0.6 + np.array([0.85, 0.75, 0.5]) * 0.4
    cold = (temp < 0.25) & (height >= 0)
    rgb[cold] = rgb[cold] * 0.5 + 0.5
    r = river_map > 0
    rgb[r] = [0.15, 0.35, 0.85]
    return np.clip(rgb, 0, 1)


def color_tilemap(tilemap):
    h = tilemap["height"]
    t = tilemap["temperature"]
    p = tilemap["precipitation"]
    r = tilemap["river"]
    return color_final(h, t, p, r)


def color_winds(cfg):
    """Small helper: draw prevailing wind bands to help visualize the model."""
    from .climate import _wind_field
    U, V = _wind_field(cfg)
    H, W = U.shape
    rgb = np.zeros((H, W, 3), dtype=np.float32)
    # east-going (westerlies) green, west-going (trades/polar) orange
    east = U > 0
    west = U < 0
    mag = np.clip(np.abs(U), 0, 1)
    rgb[east] = np.stack([0.2 + 0.0 * mag[east], 0.4 + 0.5 * mag[east], 0.2 + 0.2 * mag[east]], axis=-1)
    rgb[west] = np.stack([0.4 + 0.5 * mag[west], 0.35 + 0.2 * mag[west], 0.1 + 0.0 * mag[west]], axis=-1)
    return rgb


def color_isometric(height, colored=None, tile_h_scale=0.35, sea_level=0.0):
    """Render an isometric 3D-ish view of the heightmap.

    Projection: (x, y, z=height) -> (px, py) with a 2:1 isometric tilt.
        px = (x - y) * 1.0
        py = (x + y) * 0.5 - z * tile_h_scale * H
    Includes directional shading using the height gradient (sun from NW).
    Returns an RGB array (H_iso, W_iso, 3) suitable for st.image.
    """
    H, W = height.shape
    if colored is None:
        colored = color_height(height)

    # shading based on gradient (sun from top-left)
    gy, gx = np.gradient(height.astype(np.float32))
    # normal approximation
    nz = 1.0
    nlen = np.sqrt(gx * gx + gy * gy + nz * nz) + 1e-6
    # light vector (from NW, above)
    Lx, Ly, Lz = -0.7, -0.7, 0.9
    Llen = np.sqrt(Lx * Lx + Ly * Ly + Lz * Lz)
    Lx, Ly, Lz = Lx / Llen, Ly / Llen, Lz / Llen
    # dot(N, L) where N = (-gx, -gy, 1)/nlen
    dot = (-gx * Lx - gy * Ly + nz * Lz) / nlen
    shade = np.clip(0.45 + 0.85 * dot, 0.15, 1.35).astype(np.float32)
    shaded = np.clip(colored * shade[..., None], 0, 1)

    # canvas dimensions
    z_scale = tile_h_scale * H
    z_max = float(np.clip(height.max(), 0.0, 1.5)) * z_scale
    can_w = int(W + H) + 4
    can_h = int((W + H) * 0.5 + z_max) + 4
    canvas = np.ones((can_h, can_w, 3), dtype=np.float32) * np.array([0.06, 0.07, 0.11], dtype=np.float32)
    depth = np.full((can_h, can_w), -1e9, dtype=np.float32)  # painter's z-buffer proxy

    # draw back-to-front (far y first, then far x). In iso, "back" = small (x+y)
    # so we iterate rows top-down and within each row left-to-right (works fine here)
    x_off = int(H)  # keep px positive
    for y in range(H):
        for x in range(W):
            z = float(height[y, x])
            z_clip = max(z, sea_level)  # ocean stays flat at sea level
            px = (x - y) + x_off
            py_top = int((x + y) * 0.5 - z_clip * z_scale) + int(z_max) + 2
            if not (0 <= px < can_w):
                continue
            # draw vertical column from base to top so cliffs show
            base_py = int((x + y) * 0.5) + int(z_max) + 2
            base_py = min(base_py, can_h - 1)
            py_top = max(0, min(py_top, can_h - 1))
            # column color
            c_top = shaded[y, x]
            c_side = c_top * 0.55  # darker sides
            # only draw if in front of what is already there (depth = -(x+y))
            d = -(x + y)
            # top pixel
            if py_top >= 0 and depth[py_top, px] < d:
                canvas[py_top, px] = c_top
                depth[py_top, px] = d
                # also paint one to the right for chunkier look
                if px + 1 < can_w and depth[py_top, px + 1] < d:
                    canvas[py_top, px + 1] = c_top
                    depth[py_top, px + 1] = d
            # side (cliff) fill
            for pp in range(py_top + 1, base_py + 1):
                if 0 <= pp < can_h and depth[pp, px] < d:
                    canvas[pp, px] = c_side
                    depth[pp, px] = d
                    if px + 1 < can_w and depth[pp, px + 1] < d:
                        canvas[pp, px + 1] = c_side
                        depth[pp, px + 1] = d

    return np.clip(canvas, 0, 1)
